#!/usr/bin/env bash

# Offliner settings

OFFLINER_VERSION=1.7
OFFLINER_URL=https://repo1.maven.org/maven2/com/redhat/red/offliner/offliner/$OFFLINER_VERSION/offliner-$OFFLINER_VERSION.jar
OFFLINER_JAR=$(basename $OFFLINER_URL)

# Maven repositories
MRRC=https://maven.repository.redhat.com/ga
MAVEN_CENTRAL=https://repo1.maven.org/maven2/
JBOSS=https://repository.jboss.org/nexus/content/groups/public

REPOS=("$MAVEN_CENTRAL" "$MRRC" "$JBOSS")

function download_offliner {
    if [ ! -f "$OFFLINER_JAR" ]
    then
        echo "Downloading Offliner jar from Maven Central"
        if ! wget "$OFFLINER_URL"
        then
            echo "ERROR: Failed to download Offliner jar."
            return 1
        fi

        if ! wget "$OFFLINER_URL.md5"
        then
            echo "WARNING: Failed to download md5 for Offliner jar. Proceeding without verification."
        fi

        if [ -f "$OFFLINER_JAR.md5" ]
        then
            if ! md5sum "$OFFLINER_JAR" | cut -d ' ' -f 1 | tr -d '\n' | cmp - "$OFFLINER_JAR.md5"
            then
                echo "WARNING: MD5 of Offliner does not match downloaded checksum file."
            fi
            rm "$OFFLINER_JAR.md5"
        fi

    fi
    return 0
}

function usage {
    echo "Usage: $(basename "$0") [OPTIONS] <manifest.txt>"
    echo ""
    echo "OPTIONS: "
    echo "   -h, --help              - Display this usage."
    echo "   -d, --directory <dir>   - The download directory."
}

DOWNLOAD_DIR=repository
MANIFEST_FILE=

while [ $# -gt 0 ]
do
    arg="$1"

    case $arg in
      -d|--directory)
        shift
        DOWNLOAD_DIR="$1"
        ;;
      -h|--help)
        usage
        exit 0
        ;;
      -*)
        echo "ERROR: Unknown option '$arg'"
        exit 1
        ;;
      *)
        if [ -z "$MANIFEST_FILE" ]
        then
            MANIFEST_FILE="$1"

        else
            echo "ERROR: Manifest file already specified."
            exit 1
        fi
        ;;
    esac
    shift
done

# Verify a manifest file was specified
if [ -z "$MANIFEST_FILE" ]
then
    echo "ERROR: Manifest file was not specified."
    usage
    exit 1
fi

# Verify manifest file exists
if [ ! -f "$MANIFEST_FILE" ]
then
    echo "ERROR: No such file $MANIFEST_FILE"
    exit 1
fi

if [ ! -f "$OFFLINER_JAR" ]
then
    if ! download_offliner
    then
        exit 1
    fi
fi

eval "java -jar $OFFLINER_JAR -M -d $DOWNLOAD_DIR ${REPOS[*]/#/-r } $MANIFEST_FILE"
